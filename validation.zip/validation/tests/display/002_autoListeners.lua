-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2016 (All Rights Reserved)
-- =============================================================

-- =============================================================
-- Localizations
-- =============================================================
-- Lua
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs
local strMatch = string.match; local strGSub = string.gsub; local strSub = string.sub
--
-- Common SSK Display Object Builders
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
--
-- Common SSK Helper Modules
local easyIFC = ssk.easyIFC;local persist = ssk.persist
--
-- Common SSK Helper Functions
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
--
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
ssk.misc.countLocals(1)

-- =============================================================
-- =============================================================

-- PLUGIN REQUIRES GO HERE

-- =============================================================
local test = {}

function test.run( group, params )
   group = group or display.currentStage
   params = params or {}

	-- enterFrame
	--
	local function onEnterFrame( self, event )
		self.x = self.x + 5
		if( self.x > right ) then self.x = left end
	end
	newCircle( group, 45, top + 50,  { fill = randomColor(), enterFrame = onEnterFrame } )	

	-- touch
	local function onTouch( self, event  ) 
		self.x = event.x
		self.y = event.y
	end
	newRect( group, 45, top + 100,  { fill = randomColor(), touch = onTouch } )	

	-- timer
	local function onTimer( self ) 
		self.x = self.x + 50
		if( self.x > right ) then self.x = left end
		timer.performWithDelay( 250, self )
	end
	local tmp = newRect( group, 45, top + 150,  { fill = randomColor(), timer = onTimer } )	
	tmp:timer()

	-- mouse
	local function onMouse( self, event  ) 
		self.x = event.x
		self.y = event.y
	end
	local tmp = newRect( group, 45, top + 200,  { fill = randomColor(), mouse = onMouse } )	
	--table.dump(tmp)
	tmp:toBack()

	-- finalize
	local function onFinalize( self, event  ) 
		print("Finalizing " .. self.myName)
	end
	local tmp = newRect( group, 45, top + 250,  { fill = randomColor(), finalize = onFinalize, myName = "Bob" } )	
	display.remove( tmp )


end


return test
