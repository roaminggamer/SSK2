Downloaded from 71Squared (Particle Designer 2) website here: 

http://support.71squared.com/hc/en-us/articles/200029251-PD-2-0-Sample-Project-Exports

Please note, the zip did not come with images, so I added my own for the examples.