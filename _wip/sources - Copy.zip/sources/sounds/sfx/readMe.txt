All sounds (except gameover)  made with BFXR: http://www.bfxr.net/


