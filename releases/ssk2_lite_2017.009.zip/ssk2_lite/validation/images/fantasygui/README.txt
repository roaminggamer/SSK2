These images were extracted from this free resource:

http://opengameart.org/content/free-fantasy-game-gui

