To use this example:

+ Copy ~/extras/images/ folder here.
+ Copy ~/extras/sounds/ folder here.
+ Copy ~/extras/factories/ folder here.
+ Copy ~/ssk2/ folder here

Run the example in the simulator.




What are these batch files?

ssk2j.bat, factoriesj.bat, ..., are batch files I use to create junctions (symbolic links) to the ssk2/, factories/, etc. folders.  

I suggest you ignore these if you are not a Windows scripting expert.