Created using this editor:

http://onebyonedesign.com/flash/particleeditor/