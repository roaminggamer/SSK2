# cardgames
I'm working on modules to support various card games:
+ Generic cards (cardM.lua)
+ Black Jack (blackjackM.lua)


# slots
I'm working on an updated and more flexible slot machine module.


# spinningWheel
I'm working on a module that lets you create spinning pie-chart style wheels.  This can be used to make aWheel Of Fortune game and other spinning wheel games.






