# forestfire

Implementation of this interesting cellular automaton: http://rosettacode.org/wiki/Forest_fire

1. a burning tree disappears
2. a non-burning tree starts burning if any of its neighbors is
3. an empty spot may generate a tree with prob P
4. a non-burning tree may ignite with prob F


