# What Is This?
This folder is the _project templates_ I use when starting on new games.

+ 001_basic - Super flat project that doesn't use Tiled levels or content.  i.e. Mostly hand assembled levels.
+ 002_tiled - Tiled based games.  i.e. I edit the level(s) using tiled.
+ 003_hgen - Horizontal endless (generated level) style starter.
+ 004_vgen - Vertical endless (generated level) style starter.


