# What Is This?
This folder contains all of the factories I've developed over time to make the various games and apps found in the SSK2 extras folder.

If you don't know what a factory is, this is a good place to start learning about them:

[https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/factorymgr/](https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/factorymgr/)


# Not All Used
These are not all used in every project.  However, I like to keep them all in one place because it makes maintenance and re-use easier for me.