1. Copy ../../images/ folder here.
2. Copy ssk2/ here.

Now run it.


