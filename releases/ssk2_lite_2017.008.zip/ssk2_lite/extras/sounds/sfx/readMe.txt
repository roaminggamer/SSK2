Coin + Died sound made with BFXR: http://www.bfxr.net/


